This doesn't currnetly work, because my brain isn't working.

module.exports = {
    
    
    inputKeys: ["inputXCount", "inputYCount"],
    
    attributes: {
        "inputXCount": {
            displayName: "Count Across",
            min: 1.00,
            sliderMin: 1.00,
            sliderMax: 100.00,
            default: 3,
            type: kCIAttributeTypeScalar,
        },
        "inputYCount": {
            displayName: "Count Down",
            min: 1.00,
            sliderMin: 1.00,
            sliderMax: 100.00,
            default: 3,
            type: kCIAttributeTypeScalar,
        }
    },
    
    imagesGrid: null,
    imagesGridCurrentX: 0,
    imagesGridCurrentY: 0,
    imagesGridCurrentXCount: 0,
    imagesGridCurrentYCount: 0,
    currentImage: null,
    
    workflowStart: function(document, rbnode) {
        console.log("workflowStart ");
        
        var inputXCount = rbnode.nodeValues().inputXCount;
        var inputYCount = rbnode.nodeValues().inputYCount;
        
        console.log("inputXCount: " + inputXCount);
        console.log("inputYCount: " + inputYCount);
        
    },
    
    preflightAsset: function(document, rbnode, asset) {
        return true;
    },
    
    processAsset: function(document, rbnode, asset) {
        
        var inputXCount = rbnode.nodeValues().inputXCount;
        var inputYCount = rbnode.nodeValues().inputYCount;
        
        if (!this.imagesGrid) {
            console.log("Need to make a new grid");
            this.imagesGrid = [];
            for (var x = 0; x < inputXCount; x++) {
                this.imagesGrid[x] = [];
            }
        }
        
        var img = asset.CIImage();
        this.imagesGrid[this.imagesGridCurrentX][this.imagesGridCurrentY] = asset;
        
        console.log(this.imagesGrid[this.imagesGridCurrentX][this.imagesGridCurrentY]);
        console.log(img);
        
        this.imagesGridCurrentX++;
        if (this.imagesGridCurrentX >= inputXCount) {
            this.imagesGridCurrentX = 0;
            this.imagesGridCurrentYCount++;
        }
        
        if (this.imagesGridCurrentYCount >= inputYCount) {
            this.imagesGridCurrentYCount = 0;
            
            console.log("Making gridded asset")
            
            var newImage = this.makeGridAsset(document, rbnode);
            
            asset.setCIImage(newImage);
            
            this.imagesGrid = null;
            return true;
        }
        
        
        
        // Let's return false so our original image doesn't get processed.
        return false;
    },
    
    makeGridAsset: function(document, rbnode) {
        
        var inputXCount = rbnode.nodeValues().inputXCount;
        var inputYCount = rbnode.nodeValues().inputYCount;
        var maxX = 0;
        var maxY = 0;
        
        for (var i = 0; i < inputXCount; ++i) {
            
            for (var j = 0; j < inputYCount; ++j) {
                
                var img = this.imagesGrid[i][j];
                //var size = img.extent().size;
                
                console.log("img: " + img)
                
            }
            
        }
        
        
    }
    
};

Array.matrix = function(numrows, numcols, initial) {
    var arr = [];
    for (var i = 0; i < numrows; ++i) {
        var columns = [];
        for (var j = 0; j < numcols; ++j) {
            columns[j] = initial;
        }
        arr[i] = columns;
    }
    return arr;
}

